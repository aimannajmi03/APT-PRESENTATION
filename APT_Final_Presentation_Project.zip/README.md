# APT Case Study Presentation

This project is a React + Next.js-based interactive presentation for the Advanced Passenger Train (APT) case study.

## Instructions:
- Replace the placeholder images in `/public/images/` with real images.
- Use `npm install` and `npm run dev` to launch locally.
- Optionally deploy to a service like Vercel.
